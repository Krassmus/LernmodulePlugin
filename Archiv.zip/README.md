# LernmodulePlugin

Ein Plugin zur Darstellung von HTML-Lernmodulen in Stud.IP. Die Lernmodule müssen in einem anderen Programm erstellt werden und können dann als HTML-Lernmodul (eine ZIP-Datei) exportiert werden und werden dann in diesem Plugin in einer Stud.IP-Veranstaltung hochgeladen.
