<?php

class CoursewareController extends PluginController
{
    public function editor_action()
    {
    }
}
