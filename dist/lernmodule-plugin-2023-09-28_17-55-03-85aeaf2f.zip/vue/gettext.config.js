module.exports = {
  output: {
    locales: ['en'],
    linguas: false,
  },
};
