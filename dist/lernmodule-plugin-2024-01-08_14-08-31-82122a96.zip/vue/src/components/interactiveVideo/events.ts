export interface VideoMetadata {
  length: number;
}
